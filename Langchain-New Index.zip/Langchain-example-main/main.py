# pip install streamlit langchain openai faiss-cpu tiktoken

import os
import streamlit as st
from dotenv import load_dotenv
from streamlit_chat import message

from modules.oauth import OAuth
from modules.agent import Agent
from modules.token import Token
from modules.prompt import Prompt
from modules.chatbot import Chatbot
from modules.embedder import Embedder

from langchain.schema import AIMessage
from langchain.schema import HumanMessage
from langchain.memory import PostgresChatMessageHistory, ChatMessageHistory

load_dotenv()

user_api_key = os.environ["OPENAI_API_KEY"]
use_google_login = os.getenv(
    "USE_GOOGLE_LOGIN", 'False').lower() in ('true', '1', 't')
client_id = os.getenv("GOOGLE_CLIENT_ID", '')
client_secret = os.getenv("GOOGLE_CLIENT_SECRET", '')
redirect_uri = os.getenv("GOOGLE_REDIRECT_URI", '')
whitelisted_email_domains = dict([x, True] for x in os.getenv(
    "WHITELISTED_EMAIL_DOMAINS", '').split(","))
whitelisted_emails = dict([x, True]
                          for x in os.getenv("WHITELISTED_EMAILS", '').split(","))
postgres_conn_string = os.getenv("DB_CONN_STRING", '')
use_postgres_memory = os.getenv(
    "USE_POSTGRES_MEMORY", 'False').lower() in ('true', '1', 't')


@st.cache_data
def getVectors(uploaded_files):
    # reset vectors data
    st.session_state['vectors'] = []
    vectors_name = {}
    for uploaded_file in uploaded_files:
        # if current file already added before, skip this
        if uploaded_file.name in vectors_name:
            continue

        vectors_name[uploaded_file.name] = True
        uploaded_file.seek(0)
        file = uploaded_file.read()

        description = "use this tool when answering to a question. Search the database for the answer."

        # check if file name contain "product_list"
        if "product_list" in uploaded_file.name:
            description = description + "product list"
        elif "faq" in uploaded_file.name:
            description = description + "faq"
        elif "address" in uploaded_file.name:
            description = description + "address"

        description = description + ". Refer to Answers when answering to the query"

        embeds = Embedder()
        vector, embedding_time = embeds.getDocEmbeds(
            file, uploaded_file.name)

        st.session_state['vectors'].append(
            (vector, embedding_time, uploaded_file.name, description))

    # combine all FAISS vectors in the session state
    vectors = st.session_state['vectors'][0][0]
    for vector in st.session_state['vectors'][1:]:
        vectors.merge_from(vector[0])

    return vectors


def start_chatbot(user_id):
    # add preset files
    top_elem = st.sidebar.empty()

    uploaded_files = st.sidebar.file_uploader(
        "Upload", type="csv", accept_multiple_files=True, key='uploaded_files')

    kwargs_val = st.sidebar.slider(
        "Data Retrieval Limit", min_value=1, max_value=20, value=10, key='kwargs_val'
    )

    temperature = st.sidebar.slider(
        "Temperature", min_value=0.0, max_value=1.0, value=0.7, key='temperature'
    )

    memory_limit = st.sidebar.slider(
        "Memory limit", min_value=0, max_value=10, value=10, key="memory_limit")

    top_elem.title("Index ONLY Prototype 2")
    # chatbot_type = top_elem.radio(
    #     "Choose your chatbot type",
    #     ('Conversational Retrieval Chain', 'Agent Tools'),
    #     key='chatbot_type',
    #     disabled=len(uploaded_files) != 0
    # )
    chatbot_type = 'Conversational Retrieval Chain'

    if 'vectors_data' not in st.session_state:
        st.session_state['vectors_data'] = None

    if 'prompt' not in st.session_state:
        st.session_state['prompt'] = Prompt(user_prompt='', user_id=user_id)

    if uploaded_files:
        st.session_state['vectors_data'] = getVectors(uploaded_files)

    if st.session_state['vectors_data']:
        chatbot = Chatbot(model_name='gpt-4-0613',
                          temperature=temperature,
                          vectors=st.session_state['vectors_data'],
                          openai_key=user_api_key)

        tools = []

        if 'vectors' not in st.session_state:
            st.session_state['vectors'] = []
        for vector in st.session_state['vectors']:
            tool = chatbot.create_retrieval_qa(
                name=vector[2],
                vector=vector[0],
                description=vector[3])
            tools.append(tool)

        agent = Agent(model_name='gpt-4-0613',
                      temperature=temperature,
                      vectors=st.session_state['vectors_data'],
                      openai_key=user_api_key,
                      tools=tools)

        if 'history' not in st.session_state:
            st.session_state['history'] = []

        if 'kwargs_val_arr' not in st.session_state:
            st.session_state['kwargs_val_arr'] = []

        if 'delay' not in st.session_state:
            st.session_state['delay'] = []

        if 'token_count' not in st.session_state:
            st.session_state['token_count'] = []

        if 'user_prompt_history' not in st.session_state:
            st.session_state['user_prompt_history'] = []

        if 'generated' not in st.session_state:
            st.session_state['generated'] = []

        if 'past' not in st.session_state:
            st.session_state['past'] = []

        if 'memory' not in st.session_state:
            if use_postgres_memory:
                st.session_state['memory'] = PostgresChatMessageHistory(
                    connection_string=postgres_conn_string, session_id=user_id)
            else:
                st.session_state['memory'] = ChatMessageHistory()

            if len(st.session_state['memory'].messages) == 0:
                st.session_state['past'] = ["Start chat"]
                st.session_state['generated'] = [
                    "Hello ! Ask me anything about your csv files 🤗"]
            else:
                tmpHumanMsg = ""
                for i, obj in enumerate(st.session_state['memory'].messages):
                    if isinstance(obj, HumanMessage):
                        tmpHumanMsg = obj.content
                        st.session_state['past'].append(obj.content)
                    elif isinstance(obj, AIMessage):
                        st.session_state["history"].append(
                            (tmpHumanMsg, obj.content))
                        st.session_state['generated'].append(obj.content)
                        if 'delay' in obj.additional_kwargs:
                            st.session_state['delay'].append(
                                obj.additional_kwargs['delay'])
                        else:
                            st.session_state['delay'].append(0)

        # container for the chat history
        # response_container = st.container()
        # container for the user's text input
        container = st.container()

        with container:
            with st.form(key='my_form', clear_on_submit=True):

                user_input = st.text_input(
                    "Query:", placeholder="Question", key='input')
                submit_button = st.form_submit_button(label='Send')

            if submit_button and user_input:
                output = ''
                delay = 0

                if chatbot_type == 'Agent Tools':
                    agent_response, agent_delay = agent.chat_agent(user_input)
                    output = agent_response['output']
                    delay = agent_delay
                else:
                    chain_response, chain_delay = chatbot.conversational_chat(
                        user_input, kwargs_val, memory_limit)
                    output = chain_response
                    delay = chain_delay

                token = Token(user_input, output)
                token_count = token.get_total_token_count()

                # st.session_state["history"].append(
                #     (user_input, agent_response['output'], chain_response))

                st.session_state["history"].append(
                    (user_input, output))

                st.session_state['kwargs_val_arr'].append(kwargs_val)

                st.session_state['past'].append(user_input)
                st.session_state['generated'].append(output)

                # st.session_state['delay'].append((agent_delay, chain_delay))
                st.session_state['delay'].append(delay)

                st.session_state['token_count'].append(token_count)
                total_token_count = sum(st.session_state['token_count'])
                st.sidebar.markdown("Total Token Count:  <span style='color:#00FF00'>{}</span>".format(
                    total_token_count), unsafe_allow_html=True)

        if st.session_state['generated']:
            # with response_container:
            #     for i in range(len(st.session_state['generated'])):
            #         message(st.session_state["past"][i], is_user=True, key=str(
            #             i) + '_user', avatar_style="big-smile")
            #         message(st.session_state["generated"][i],
            #                 key=str(i), avatar_style="thumbs")

            history_container = st.container()
            with history_container:
                for i, (q, a) in enumerate(st.session_state['history']):
                    qa_expander = st.expander(
                        "Q&A input " + str(i + 1), expanded=False)
                    qa_expander.write("Question:")
                    qa_expander.markdown(
                        "<p style='font-family:Courier; color:#FFD200;'>" + q + "</p>", unsafe_allow_html=True)

                    # agent_expander = st.expander(
                    #     "Agent", expanded=False)
                    # agent_expander.write("Answer:")
                    # agent_expander.markdown("<p style='font-family:Courier; color:#00D9FF;'>" +
                    #                         agent_answer + "</p>", unsafe_allow_html=True)
                    # agent_expander.write("Generated in: <span style='color:#00D9FF'>" +
                    #                      str(st.session_state['delay'][i][0]) + "s</span>", unsafe_allow_html=True)

                    # conv_retr_expander = st.expander(
                    #     "Conversational Retrieval", expanded=False)
                    # conv_retr_expander.write(
                    #     "Answer:")
                    # conv_retr_expander.markdown("<div style='font-family:Courier; color:#A200FF;'>" +
                    #                             conv_retr_answer + "</div>", unsafe_allow_html=True)
                    # conv_retr_expander.write("Generated in: <span style='color:#A200FF'>" +
                    #                          str(st.session_state['delay'][i][1]) + "s</span>", unsafe_allow_html=True)

                    qa_expander.write("Answer:")
                    qa_expander.markdown("<p style='font-family:Courier; color:#00D9FF;'>" +
                                         a + "</p>", unsafe_allow_html=True)

                    qa_expander.write("Generated in: <span style='color:#00FF00; font-weight: bold;'>" +
                                      str(st.session_state['delay'][i]) + "s</span>", unsafe_allow_html=True)

                    qa_expander.write("Data Retrieval Limit: <span style='color:#00FF00; font-weight: bold;'>" +
                                      str(st.session_state['kwargs_val_arr'][i]) + "</span>", unsafe_allow_html=True)

                    qa_expander.write("Token Count: <span style='color:#00FF00; font-weight: bold;'>" +
                                      str(st.session_state['token_count'][i]) + "</span>", unsafe_allow_html=True)

                    qa_expander.write("Prompt:")
                    qa_expander.markdown("<p style='font-family:Courier; color:#AFAFAF;'>" +
                                         st.session_state['user_prompt_history'][i] + "</p>", unsafe_allow_html=True)

        st.sidebar.text_area(
            "User Prompt", key='user_prompt_input', value=st.session_state['user_prompt'], on_change=st.session_state['prompt'].set_prompt, height=500)

        if st.session_state['history']:
            user_summary_button = st.sidebar.button("User Summary")

            if user_summary_button:
                aiSummary, token_count = chatbot.conversation_summary()
                st.sidebar.markdown(aiSummary, unsafe_allow_html=True)
                st.sidebar.markdown("Summary Token Count: <span style='color:#00FF00'>{}<span>".format(
                    token_count), unsafe_allow_html=True)


def is_email_allowed(email):
    inputEmailDomain = email.rsplit('@', 1)[-1]
    if inputEmailDomain in whitelisted_email_domains:
        return True

    if email in whitelisted_emails:
        return True

    return False


if __name__ == "__main__":
    if use_google_login == True:
        app_name = '''
        Langchain PoC Demo
        '''
        app_desc = '''
        Proof of concept of using langchain as chatbot framework
        '''
        oauth = OAuth(client_id, client_secret, redirect_uri)
        login_info = oauth.login(
            app_name=app_name,
            app_desc=app_desc,
        )
        if login_info:
            user_id, user_email = login_info
            if is_email_allowed(user_email):
                start_chatbot(user_id)
            else:
                "Forbidden Login"
    else:
        start_chatbot(0)

# streamlit run main.py
