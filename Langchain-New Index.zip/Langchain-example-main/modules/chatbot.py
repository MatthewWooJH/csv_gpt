import os
import time
import tiktoken
import streamlit as st
from modules.tools import Tools
from dotenv import load_dotenv
from langchain.chat_models import ChatOpenAI
from langchain.prompts.prompt import PromptTemplate
# from langchain.callbacks import get_openai_callback
from langchain.schema import HumanMessage, AIMessage
from langchain.memory import ConversationSummaryMemory, ConversationBufferWindowMemory
from langchain.chains import ConversationalRetrievalChain, RetrievalQA


load_dotenv()
use_postgres_memory = os.getenv("USE_POSTGRES_MEMORY", False)


class Chatbot:
    def __init__(self, model_name, temperature, vectors, openai_key):
        self.model_name = model_name
        self.temperature = temperature
        self.vectors = vectors
        self.openai_key = openai_key
        self.llm = ChatOpenAI(model_name=self.model_name,
                              temperature=self.temperature,
                              openai_api_key=self.openai_key,
                              max_tokens=2048)

    qa_template = """
        Context information is below.
        =========
        context: {context}
        =========
        Given the context information and not prior knowledge, answer the question: {question}
        """

    condense_question_template = """Given the following conversation and a follow-up question, rephrase the follow-up question to be a standalone question.
        Chat History:
        {chat_history}
        Follow-up input: {question}
        Standalone question:"""

    def conversational_chat(self, query, kwargs_val, memory_limit):
        """
        Start a conversational chat with a model via Langchain
        """
        start = time.time()

        retriever = self.vectors.as_retriever()
        retriever.search_kwargs = {'k': kwargs_val}

        full_template = st.session_state['user_prompt_input'] + \
            self.qa_template
        QA_PROMPT = PromptTemplate(template=full_template, input_variables=[
            "context", "question"])
        CONDENSE_QUESTION_PROMPT = PromptTemplate.from_template(
            self.condense_question_template)

        st.session_state["user_prompt_history"].append(
            st.session_state['user_prompt_input'])

        memory = ConversationBufferWindowMemory(
            memory_key="chat_history", input_key='question', output_key='answer', return_messages=True, k=memory_limit)

        chain = ConversationalRetrievalChain.from_llm(llm=self.llm,
                                                      retriever=retriever,
                                                      verbose=True,
                                                      memory=memory,
                                                      condense_question_prompt=CONDENSE_QUESTION_PROMPT,
                                                      return_source_documents=True,
                                                      combine_docs_chain_kwargs={'prompt': QA_PROMPT})

        chain_input = {"question": query}
        result = chain(chain_input)

        delay = time.time() - start

        if use_postgres_memory:
            st.session_state['memory'].add_message(HumanMessage(
                content=query, additional_kwargs={'delay': delay}))
            st.session_state['memory'].add_message(
                AIMessage(content=result["answer"], additional_kwargs={'delay': delay}))
        else:
            st.session_state['memory'].add_user_message(query)
            st.session_state['memory'].add_ai_message(result["answer"])

        return result["answer"], delay

    def conversation_summary(self):
        memory = ConversationSummaryMemory(llm=self.llm,
                                           return_messages=True,)
        for question, answer in st.session_state["history"]:
            memory.save_context({"input": question}, {"output": answer})

        messages = memory.chat_memory.messages
        previous_summary = ""
        summary = memory.predict_new_summary(messages, previous_summary)
        summary_tokens = self.enc.encode(summary)
        summary_token_count = len(summary_tokens)

        return summary, summary_token_count

    def create_retrieval_qa(self, name, description, vector):
        qa = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=vector.as_retriever()
        )

        tools = Tools(qa=qa, name=name, description=description)

        tool = tools.generate_tool()

        return tool
