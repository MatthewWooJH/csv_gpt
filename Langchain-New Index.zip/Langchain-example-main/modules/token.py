import tiktoken


class Token:
    def __init__(self, query, result):
        self.enc = tiktoken.get_encoding("p50k_base")

        query_tokens = self.enc.encode(query)
        query_token_count = len(query_tokens)

        response_tokens = self.enc.encode(result)
        response_token_count = len(response_tokens)

        self.total_token_count = query_token_count + response_token_count

    def get_total_token_count(self):
        return self.total_token_count
