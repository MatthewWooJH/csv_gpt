import os
import psycopg2
import streamlit as st
from dotenv import load_dotenv


class Prompt:
    def __init__(self, user_prompt, user_id):
        self.user_id=user_id
        default_prompt = '''# General Role
You have two roles: 
As a sales chatbot, you're tasked to help USER find the right product(s)/service(s) and convince them to use those product(s)/service(s) in such a way that USER feels understood, supported, and personalized by providing a conversational commerce experience.
As a FAQ chatbot, you are tasked to retrieve information from the database and answer to the user's question and concern. If you don't know the answer, just say that you don't know, don't try to make up an answer.
When user ask questions related to location. Always provide the address.
'''

        self.connect_db()

        # prioritize using user_prompt input, then from db, and then from default prompt
        if user_prompt == '':
            db_prompt = self.get_db_prompt()
            if db_prompt != '':
                self.prompt = db_prompt
            else:
                self.prompt = default_prompt
        else:
            self.prompt = user_prompt

        if 'user_prompt' not in st.session_state:
            st.session_state['user_prompt'] = ''
        st.session_state['user_prompt'] = self.prompt

    def get_db_prompt(self):
        if self.use_db is False:
            return ''

        query = """SELECT default_prompt FROM langchain_prompt
                    WHERE user_id = %s
            """
        self.cursor.execute(query, (str(self.user_id),))
        rows = self.cursor.fetchall()
        result = ""
        for row in rows:
            result = row[0]
            break

        return result

    def set_prompt(self):
        self.prompt = st.session_state.user_prompt_input
        st.session_state['user_prompt'] = st.session_state.user_prompt_input

        if self.use_db:
            query = """INSERT INTO langchain_prompt(user_id, default_prompt)
                    VALUES(%s,%s)
                    ON CONFLICT (user_id) 
                    DO UPDATE SET default_prompt = %s
                """
            self.cursor.execute(
                query, 
                (self.user_id, self.prompt, self.prompt,))
            self.db.commit()

    def connect_db(self):
        load_dotenv()
        self.use_db = os.getenv("USE_POSTGRES_PROMPT", 'False').lower() in ('true', '1', 't')
        if self.use_db == False:
            return

        postgres_conn_string = os.getenv("DB_CONN_STRING", '')
        if postgres_conn_string == '':
            self.use_db = False
            return
        
        try:
            self.db = psycopg2.connect(postgres_conn_string)
            self.cursor = self.db.cursor()
        except Exception as e:
            print(e)
            self.use_db = False
            return

        # create DB if not exist
        create_table_query = f"""CREATE TABLE IF NOT EXISTS langchain_prompt (
            user_id varchar(30) PRIMARY KEY,
            default_prompt TEXT NOT NULL
        );"""
        self.cursor.execute(create_table_query)
        self.db.commit()
