import streamlit as st
import asyncio
import json
from requests_oauthlib import OAuth2Session

class OAuth:
    authorization_base_url = "https://accounts.google.com/o/oauth2/v2/auth"
    token_url = "https://www.googleapis.com/oauth2/v4/token"
    scope = [
        "openid",
        "https://www.googleapis.com/auth/userinfo.email",
        "https://www.googleapis.com/auth/userinfo.profile"
    ]
   
    def __init__(self, client_id, client_secret, redirect_uri):
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.google = OAuth2Session(client_id, scope=self.scope, redirect_uri=redirect_uri)

    def get_authorization_url(self):
        authorization_url, state = self.google.authorization_url(self.authorization_base_url,
            access_type="offline", prompt="select_account")
        return authorization_url

    def write_access_token(self, code):
        token = self.google.fetch_token(self.token_url, client_secret=self.client_secret, 
            code=code)
        return token


    async def get_user_info(self):
        r = self.google.get('https://www.googleapis.com/oauth2/v1/userinfo')
        aDict = json.loads(r.content)
        return aDict["id"], aDict["email"]


    async def revoke_token(self, client, token):
        return await client.revoke_token(token)


    def login_button(self, authorization_url, app_name, app_desc):
        st.markdown('''<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">''',
        unsafe_allow_html=True)

        container = f'''
        <div class="container-fluid border py-4 px-4 border-primary">
            <h5><strong>{app_name}</strong></h5>
            <p>{app_desc}</p>
            <a target="_self" href="{authorization_url}">
                <img class="img-fluid" src="https://i.imgur.com/YTxsnUl.png" alt="streamlit">
            </a>
        </div>
        '''
        st.markdown(container, unsafe_allow_html=True)


    def login(
        self,
        app_name="Continue with Google",
        app_desc="",
    ):
        app_desc
        if "token" not in st.session_state:
            st.session_state.token = None

        if st.session_state.token is None:
            try:
                code = st.experimental_get_query_params()["code"][0]
            except:
                self.login_button(self.get_authorization_url(), app_name, app_desc)
            else:
                # Verify token is correct:
                try:
                    token = self.google.fetch_token(self.token_url, client_secret=self.client_secret, 
                        code=code)
                except Exception as e:
                    self.login_button(self.get_authorization_url(), app_name, app_desc)
                else:
                    # Check if token has expired:
                    if token["expires_in"] <= 0:
                        self.login_button(self.get_authorization_url(), app_name, app_desc)
                    else:
                        st.session_state.token = token
                        st.session_state.user_id, st.session_state.user_email = asyncio.run(
                            self.get_user_info()
                        )
                        return (st.session_state.user_id, st.session_state.user_email)
        else:
            return (st.session_state.user_id, st.session_state.user_email)
