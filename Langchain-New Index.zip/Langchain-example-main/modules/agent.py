# import streamlit as st
# from langchain.chains import LLMChain
# from langchain.agents import BaseAgent
# from langchain.chat_models import ChatOpenAI
# from langchain.chains.conversational_retrieval.prompts import CONDENSE_QUESTION_PROMPT


# class CustomAgent(BaseAgent):
#     def __init__(self, model_name, vectors, temperature, openai_key):
#         self.model_name = model_name
#         self.temperature = temperature
#         self.vectors = vectors
#         self.openai_key = openai_key
#         self.llm = ChatOpenAI(model_name=self.model_name,
#                               temperature=self.temperature,
#                               openai_api_key=self.openai_key,
#                               max_tokens=2048)
#         self.chain = LLMChain(llm=self.llm, prompt=CONDENSE_QUESTION_PROMPT)

#     def run(self, input):
#         return self.chain.run(input)

import time
import tiktoken

from langchain.chat_models import ChatOpenAI
from langchain.agents import initialize_agent
from langchain.chains.conversation.memory import ConversationBufferWindowMemory


class Agent:
    def __init__(self, model_name, temperature, vectors, openai_key, tools):
        self.model_name = model_name
        self.temperature = temperature
        self.vectors = vectors
        self.openai_key = openai_key
        self.tools = tools
        self.enc = tiktoken.get_encoding("p50k_base")
        self.llm = ChatOpenAI(model_name=self.model_name,
                              temperature=self.temperature,
                              openai_api_key=self.openai_key,
                              max_tokens=2048)
        self.conversational_memory = ConversationBufferWindowMemory(
            memory_key='chat_history',
            k=3,
            return_messages=True
        )

    def chat_agent(self, query):
        start_time = time.time()

        agent = initialize_agent(
            agent='chat-conversational-react-description',
            tools=self.tools,
            llm=self.llm,
            verbose=True,
            max_iterations=3,
            early_stopping_method='generate',
            memory=self.conversational_memory
        )

        result = agent(query)

        delay = time.time() - start_time

        return result, delay
