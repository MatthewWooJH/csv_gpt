from langchain.agents import Tool


class Tools:
    def __init__(self, qa, name, description):
        self.qa = qa
        self.name: str = name
        self.description: str = description

    def generate_tool(self):
        tool = Tool(
            name=self.name,
            func=self.qa.run,
            description=(self.description)
        )
        return tool
